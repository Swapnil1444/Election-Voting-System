CREATE DATABASE election_db;
USE election_db;

CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    address VARCHAR(255),
    votes INT DEFAULT 0
);

CREATE TABLE voters (
    voter_id VARCHAR(50) PRIMARY KEY
);

select * from voters;
select * from candidates;


